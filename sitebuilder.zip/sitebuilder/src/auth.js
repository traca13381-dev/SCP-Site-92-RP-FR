'use strict';
const crypto = require('crypto');
const db = require('./db');
const { randomToken, parseCookies } = require('./util');

const SESSION_TTL_MS = 7 * 24 * 60 * 60 * 1000; // 7 days
const MAX_LOGIN_ATTEMPTS = 5;
const LOCKOUT_MINUTES = 15;

function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(password, salt, 64);
  return `scrypt$${salt.toString('hex')}$${hash.toString('hex')}`;
}

function verifyPassword(password, stored) {
  try {
    const [scheme, saltHex, hashHex] = stored.split('$');
    if (scheme !== 'scrypt') return false;
    const salt = Buffer.from(saltHex, 'hex');
    const expected = Buffer.from(hashHex, 'hex');
    const actual = crypto.scryptSync(password, salt, 64);
    return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
  } catch {
    return false;
  }
}

function hasAdminUser() {
  const row = db.prepare('SELECT id FROM users LIMIT 1').get();
  return !!row;
}

function createAdminUser(username, password) {
  const role = db.prepare('SELECT id FROM roles WHERE name = ?').get('admin');
  const hash = hashPassword(password);
  const info = db
    .prepare('INSERT INTO users (username, password_hash, role_id) VALUES (?, ?, ?)')
    .run(username, hash, role.id);
  return info.lastInsertRowid;
}

function getUserByUsername(username) {
  return db.prepare('SELECT * FROM users WHERE username = ?').get(username);
}

// --- Login rate limiting (per source IP) ---
function checkLoginAllowed(ip) {
  const row = db.prepare('SELECT * FROM login_attempts WHERE ip = ?').get(ip);
  if (!row || !row.locked_until) return { allowed: true };
  const lockedUntil = new Date(row.locked_until + 'Z').getTime();
  if (Date.now() < lockedUntil) {
    return { allowed: false, retryAt: new Date(lockedUntil) };
  }
  return { allowed: true };
}

function recordLoginFailure(ip) {
  const row = db.prepare('SELECT * FROM login_attempts WHERE ip = ?').get(ip);
  const count = (row ? row.count : 0) + 1;
  let lockedUntil = null;
  if (count >= MAX_LOGIN_ATTEMPTS) {
    lockedUntil = new Date(Date.now() + LOCKOUT_MINUTES * 60 * 1000).toISOString().replace('Z', '');
  }
  db.prepare(
    `INSERT INTO login_attempts (ip, count, locked_until) VALUES (?, ?, ?)
     ON CONFLICT(ip) DO UPDATE SET count = excluded.count, locked_until = excluded.locked_until`
  ).run(ip, count, lockedUntil);
}

function clearLoginFailures(ip) {
  db.prepare('DELETE FROM login_attempts WHERE ip = ?').run(ip);
}

// --- Sessions ---
function createSession(userId) {
  const token = randomToken(32);
  const csrfToken = randomToken(32);
  const expires = new Date(Date.now() + SESSION_TTL_MS).toISOString().replace('Z', '');
  db.prepare(
    'INSERT INTO sessions (token, user_id, csrf_token, expires_at) VALUES (?, ?, ?, ?)'
  ).run(token, userId, csrfToken, expires);
  return token;
}

function destroySession(token) {
  db.prepare('DELETE FROM sessions WHERE token = ?').run(token);
}

function getSessionFromRequest(req) {
  const cookies = parseCookies(req);
  const token = cookies.session;
  if (!token) return null;
  const session = db.prepare('SELECT * FROM sessions WHERE token = ?').get(token);
  if (!session) return null;
  if (new Date(session.expires_at + 'Z').getTime() < Date.now()) {
    destroySession(token);
    return null;
  }
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(session.user_id);
  if (!user) return null;
  return { token, user, csrfToken: session.csrf_token };
}

function verifyCsrf(session, submittedToken) {
  if (!session || !submittedToken) return false;
  const a = Buffer.from(session.csrfToken);
  const b = Buffer.from(String(submittedToken));
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

module.exports = {
  hashPassword,
  verifyPassword,
  hasAdminUser,
  createAdminUser,
  getUserByUsername,
  checkLoginAllowed,
  recordLoginFailure,
  clearLoginFailures,
  createSession,
  destroySession,
  getSessionFromRequest,
  verifyCsrf,
};
