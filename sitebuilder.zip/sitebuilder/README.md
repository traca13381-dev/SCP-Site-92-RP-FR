# SiteBuilder — plateforme personnelle de création de sites web

Application **mono-utilisateur** (un seul compte administrateur) pour créer,
gérer et publier gratuitement des sites web publics, conformément au cahier
des charges. **Zéro dépendance externe** : uniquement les modules intégrés
de Node.js (`http`, `node:sqlite`, `crypto`). Aucune connexion internet ni
`npm install` requis.

## Prérequis

- Node.js **22.5 ou supérieur** (pour le module intégré `node:sqlite`).

## Démarrage

```bash
node server.js
```

Puis ouvrez `http://localhost:3000`. Au tout premier lancement, vous serez
redirigé vers `/setup` pour créer votre compte administrateur (nom
d'utilisateur + mot de passe, 12 caractères minimum). Cette page ne
s'affiche qu'une seule fois.

La base de données SQLite est créée automatiquement dans `data/sitebuilder.db`.

## Fonctionnalités livrées

- **Compte admin unique** : connexion sécurisée, changement de mot de passe,
  verrouillage temporaire après 5 échecs de connexion (protection brute-force).
- **Rôles & permissions** : table `roles` en base, prête à accueillir de
  nouveaux rôles/permissions plus tard sans migration de schéma.
- **Sites illimités** : création à partir d'un modèle (page vide, page
  d'accueil simple, portfolio), renommage, suppression, statut public/privé,
  dates de création/modification, compteur de vues.
- **Pages multiples par site**, avec un éditeur de blocs : texte, image,
  vidéo (embed), bouton, formulaire de contact. Ajout, suppression et
  réordonnancement des blocs. Aperçu avant publication.
- **Publication gratuite** : chaque site public est accessible via
  `/s/<slug>` et `/s/<slug>/<page-slug>`, sans configuration supplémentaire.
- **Formulaires** : les soumissions des visiteurs sont stockées dans la
  table `submissions` (site_id, page_id, données JSON, date).
- **Tableau de bord** : liste des sites, statut, lien public, vues,
  dates — le tout depuis `/dashboard`.
- **Sécurité** :
  - Mots de passe hachés avec `scrypt` + sel aléatoire (jamais stockés en clair).
  - Jeton CSRF unique par session, vérifié sur tous les formulaires POST.
  - Toutes les valeurs utilisateur sont échappées avant injection HTML
    (protection XSS), y compris sur les pages publiques.
  - Toutes les requêtes SQL sont paramétrées (protection injection SQL).
  - Cookies de session `HttpOnly` + `SameSite`; `Secure` activable via
    `FORCE_SECURE_COOKIE=1` en production HTTPS.
  - En-têtes `X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`.
  - Limitation des tentatives de connexion (5 essais puis verrouillage 15 min).

## Sauvegarde des données

Toute la base est un unique fichier : `data/sitebuilder.db` (+ fichiers
`-wal`/`-shm` du mode WAL). Pour sauvegarder, il suffit de copier ce
dossier pendant que le serveur est arrêté, ou d'utiliser l'utilitaire
`sqlite3 data/sitebuilder.db ".backup data/backup.db"` à chaud.

## Limites actuelles / pistes d'évolution

Ce socle couvre l'intégralité du cahier des charges fonctionnellement, avec
quelques simplifications assumées pour rester à zéro dépendance :

- Les images/vidéos sont ajoutées par **URL** (pas d'upload de fichier sur le
  serveur) — un module d'upload pourrait être ajouté ensuite.
- L'éditeur de blocs est **piloté par formulaires serveur** (boutons
  Monter/Descendre) plutôt qu'un glisser-déposer JavaScript ; l'expérience
  est fonctionnelle et robuste, un vrai drag-and-drop visuel serait une
  phase 2.
- Pas encore de sélection fine de thèmes/CSS par site (un seul thème
  "default" actuellement) — le champ `theme` existe déjà en base pour
  l'ajouter facilement.
- Statistiques limitées à un compteur de vues par site/page (pas encore de
  graphique dans le temps).

## Structure du projet

```
server.js          Serveur HTTP + routage
src/db.js           Schéma SQLite (users, roles, sessions, sites, pages, submissions)
src/auth.js          Authentification, sessions, CSRF, rate limiting
src/blocks.js         Définition et rendu des blocs de contenu
src/templates.js       Modèles de démarrage pour un nouveau site
src/layout.js          Gabarit HTML de l'interface d'administration
src/util.js            Fonctions utilitaires (échappement HTML, cookies, parsing)
public/style.css      Styles de l'interface d'administration
public/public.css      Styles des sites publiés
```
