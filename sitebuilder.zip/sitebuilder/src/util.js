'use strict';
const crypto = require('crypto');
const querystring = require('querystring');

// --- XSS protection: escape any user-controlled string before injecting into HTML ---
function escapeHtml(str) {
  if (str === undefined || str === null) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// Escape a value for safe use inside an HTML attribute (href/src). Also blocks
// javascript: and data: URI XSS vectors on user-supplied links/images/videos.
function safeUrl(str) {
  const s = String(str || '').trim();
  if (/^javascript:/i.test(s) || /^data:/i.test(s)) return '';
  return escapeHtml(s);
}

function randomToken(bytes = 32) {
  return crypto.randomBytes(bytes).toString('hex');
}

function parseCookies(req) {
  const header = req.headers.cookie;
  const out = {};
  if (!header) return out;
  header.split(';').forEach(pair => {
    const idx = pair.indexOf('=');
    if (idx === -1) return;
    const k = pair.slice(0, idx).trim();
    const v = pair.slice(idx + 1).trim();
    out[k] = decodeURIComponent(v);
  });
  return out;
}

function readBody(req, maxBytes = 5 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', chunk => {
      size += chunk.length;
      if (size > maxBytes) {
        reject(new Error('Payload too large'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

async function parseFormBody(req) {
  const buf = await readBody(req);
  const raw = buf.toString('utf8');
  const parsed = querystring.parse(raw);
  // Normalize array-style fields like blocks[0][type]
  return parsed;
}

module.exports = { escapeHtml, safeUrl, randomToken, parseCookies, readBody, parseFormBody };
