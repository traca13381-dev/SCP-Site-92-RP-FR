'use strict';

const TEMPLATES = {
  blank: { label: 'Page vide', blocks: () => [] },
  landing: {
    label: 'Page d\'accueil simple',
    blocks: () => [
      { type: 'text', text: 'Bienvenue sur mon site !' },
      { type: 'text', text: 'Décrivez ici votre projet, votre activité ou vous-même.' },
      { type: 'button', label: 'En savoir plus', url: '#' },
    ],
  },
  portfolio: {
    label: 'Portfolio',
    blocks: () => [
      { type: 'text', text: 'Mon Portfolio' },
      { type: 'image', url: '', alt: 'Photo de présentation' },
      { type: 'text', text: 'Quelques mots sur mon parcours et mes réalisations.' },
      { type: 'form', title: 'Me contacter', fields: 'nom,email,message' },
    ],
  },
};

module.exports = { TEMPLATES };
