'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');

const db = require('./src/db');
const auth = require('./src/auth');
const { layout } = require('./src/layout');
const { escapeHtml, parseFormBody, randomToken } = require('./src/util');
const blocks = require('./src/blocks');
const { TEMPLATES } = require('./src/templates');

const PORT = process.env.PORT || 3000;
const IS_HTTPS = process.env.FORCE_SECURE_COOKIE === '1';

// ---------- tiny router ----------
const routes = [];
function on(method, pattern, handler) {
  const paramNames = [];
  const regexStr = pattern.replace(/:([A-Za-z0-9_]+)/g, (_, name) => {
    paramNames.push(name);
    return '([^/]+)';
  });
  routes.push({ method, regex: new RegExp(`^${regexStr}$`), paramNames, handler });
}

function setCookie(res, name, value, opts = {}) {
  const parts = [`${name}=${encodeURIComponent(value)}`];
  parts.push(`Path=${opts.path || '/'}`);
  parts.push('HttpOnly');
  parts.push(`SameSite=${opts.sameSite || 'Lax'}`);
  if (IS_HTTPS) parts.push('Secure');
  if (opts.maxAge) parts.push(`Max-Age=${opts.maxAge}`);
  if (opts.expires === 0) parts.push('Max-Age=0');
  const existing = res.getHeader('Set-Cookie');
  const arr = existing ? (Array.isArray(existing) ? existing : [existing]) : [];
  arr.push(parts.join('; '));
  res.setHeader('Set-Cookie', arr);
}

function send(res, status, body, headers = {}) {
  res.writeHead(status, {
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    ...headers,
  });
  res.end(body);
}

function html(res, status, body, extraHeaders = {}) {
  send(res, status, body, { 'Content-Type': 'text/html; charset=utf-8', ...extraHeaders });
}

function redirect(res, location) {
  send(res, 302, '', { Location: location });
}

function getClientIp(req) {
  return req.socket.remoteAddress || 'unknown';
}

function page(opts) {
  return layout(opts);
}

// ---------- auth guard ----------
function requireAuth(req, res) {
  const session = auth.getSessionFromRequest(req);
  if (!session) {
    redirect(res, '/login');
    return null;
  }
  return session;
}

function requireCsrf(session, fields, res) {
  if (!auth.verifyCsrf(session, fields._csrf)) {
    html(res, 403, page({ title: 'Erreur', body: '<p>Jeton de sécurité invalide (CSRF). Veuillez réessayer.</p><p><a href="javascript:history.back()">Retour</a></p>' }));
    return false;
  }
  return true;
}

// ===================== SETUP (first run) =====================
on('GET', '/setup', (req, res) => {
  if (auth.hasAdminUser()) return redirect(res, '/login');
  html(res, 200, page({
    title: 'Configuration initiale',
    body: `
    <div class="card auth-card">
      <h1>Créer le compte administrateur</h1>
      <p class="muted">Cette étape ne s'affiche qu'une seule fois.</p>
      <form method="POST" action="/setup">
        <label>Nom d'utilisateur<input type="text" name="username" required autofocus></label>
        <label>Mot de passe (12 caractères minimum)<input type="password" name="password" minlength="12" required></label>
        <label>Confirmer le mot de passe<input type="password" name="password2" minlength="12" required></label>
        <button type="submit" class="primary">Créer mon compte</button>
      </form>
    </div>`
  }));
});

on('POST', '/setup', async (req, res) => {
  if (auth.hasAdminUser()) return redirect(res, '/login');
  const fields = await parseFormBody(req);
  const username = (fields.username || '').trim();
  const password = fields.password || '';
  if (username.length < 3 || password.length < 12 || password !== fields.password2) {
    html(res, 400, page({
      title: 'Configuration initiale',
      body: `<div class="card auth-card"><p class="error">Nom d'utilisateur (min. 3 caractères) invalide, mot de passe trop court (min. 12) ou non concordant.</p><p><a href="/setup">Réessayer</a></p></div>`
    }));
    return;
  }
  auth.createAdminUser(username, password);
  redirect(res, '/login');
});

// ===================== LOGIN / LOGOUT =====================
on('GET', '/login', (req, res) => {
  if (!auth.hasAdminUser()) return redirect(res, '/setup');
  const session = auth.getSessionFromRequest(req);
  if (session) return redirect(res, '/dashboard');
  html(res, 200, page({
    title: 'Connexion',
    body: `
    <div class="card auth-card">
      <h1>Connexion</h1>
      <form method="POST" action="/login">
        <label>Nom d'utilisateur<input type="text" name="username" required autofocus></label>
        <label>Mot de passe<input type="password" name="password" required></label>
        <button type="submit" class="primary">Se connecter</button>
      </form>
    </div>`
  }));
});

on('POST', '/login', async (req, res) => {
  const ip = getClientIp(req);
  const gate = auth.checkLoginAllowed(ip);
  if (!gate.allowed) {
    html(res, 429, page({ title: 'Connexion', body: `<div class="card auth-card"><p class="error">Trop de tentatives échouées. Réessayez après ${gate.retryAt.toLocaleTimeString('fr-FR')}.</p></div>` }));
    return;
  }
  const fields = await parseFormBody(req);
  const user = auth.getUserByUsername((fields.username || '').trim());
  const ok = user && auth.verifyPassword(fields.password || '', user.password_hash);
  if (!ok) {
    auth.recordLoginFailure(ip);
    html(res, 401, page({ title: 'Connexion', body: `<div class="card auth-card"><p class="error">Identifiants invalides.</p><p><a href="/login">Réessayer</a></p></div>` }));
    return;
  }
  auth.clearLoginFailures(ip);
  const token = auth.createSession(user.id);
  setCookie(res, 'session', token, { maxAge: 7 * 24 * 3600 });
  redirect(res, '/dashboard');
});

on('POST', '/logout', (req, res) => {
  const session = auth.getSessionFromRequest(req);
  if (session) auth.destroySession(session.token);
  setCookie(res, 'session', '', { expires: 0 });
  redirect(res, '/login');
});

// ===================== ACCOUNT =====================
on('GET', '/account', (req, res) => {
  const session = requireAuth(req, res);
  if (!session) return;
  html(res, 200, page({
    title: 'Mon compte',
    user: session.user,
    body: `
    <h1>Mon compte</h1>
    <div class="card">
      <p><strong>Utilisateur :</strong> ${escapeHtml(session.user.username)}</p>
      <h2>Changer mon mot de passe</h2>
      <form method="POST" action="/account/password">
        <input type="hidden" name="_csrf" value="${escapeHtml(session.csrfToken)}">
        <label>Mot de passe actuel<input type="password" name="current" required></label>
        <label>Nouveau mot de passe (12 caractères min.)<input type="password" name="new1" minlength="12" required></label>
        <label>Confirmer<input type="password" name="new2" minlength="12" required></label>
        <button type="submit" class="primary">Mettre à jour</button>
      </form>
    </div>`
  }));
});

on('POST', '/account/password', async (req, res) => {
  const session = requireAuth(req, res);
  if (!session) return;
  const fields = await parseFormBody(req);
  if (!requireCsrf(session, fields, res)) return;
  if (!auth.verifyPassword(fields.current || '', session.user.password_hash)) {
    html(res, 400, page({ title: 'Mon compte', user: session.user, body: '<p class="error">Mot de passe actuel incorrect.</p><p><a href="/account">Retour</a></p>' }));
    return;
  }
  if ((fields.new1 || '').length < 12 || fields.new1 !== fields.new2) {
    html(res, 400, page({ title: 'Mon compte', user: session.user, body: '<p class="error">Nouveau mot de passe invalide ou non concordant.</p><p><a href="/account">Retour</a></p>' }));
    return;
  }
  const newHash = auth.hashPassword(fields.new1);
  db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(newHash, session.user.id);
  html(res, 200, page({ title: 'Mon compte', user: session.user, body: '<p class="success">Mot de passe mis à jour.</p><p><a href="/account">Retour</a></p>' }));
});

// ===================== DASHBOARD =====================
on('GET', '/dashboard', (req, res) => {
  const session = requireAuth(req, res);
  if (!session) return;
  const sites = db.prepare('SELECT * FROM sites WHERE owner_id = ? ORDER BY updated_at DESC').all(session.user.id);
  const rows = sites.map(s => `
    <tr>
      <td><a href="/sites/${s.id}">${escapeHtml(s.name)}</a></td>
      <td><span class="badge ${s.status}">${s.status === 'public' ? 'Public' : 'Privé'}</span></td>
      <td>${s.status === 'public' ? `<a href="/s/${escapeHtml(s.slug)}" target="_blank">/s/${escapeHtml(s.slug)}</a>` : '<span class="muted">—</span>'}</td>
      <td>${s.views}</td>
      <td>${escapeHtml(s.created_at)}</td>
      <td>${escapeHtml(s.updated_at)}</td>
    </tr>`).join('');

  const templateOptions = Object.entries(TEMPLATES).map(([k, t]) => `<option value="${k}">${escapeHtml(t.label)}</option>`).join('');

  html(res, 200, page({
    title: 'Tableau de bord',
    user: session.user,
    body: `
    <h1>Mes sites</h1>
    <div class="card">
      <h2>Créer un nouveau site</h2>
      <form method="POST" action="/sites/create">
        <input type="hidden" name="_csrf" value="${escapeHtml(session.csrfToken)}">
        <label>Nom du site<input type="text" name="name" required></label>
        <label>Modèle de départ<select name="template">${templateOptions}</select></label>
        <button type="submit" class="primary">Créer</button>
      </form>
    </div>
    <table class="data-table">
      <thead><tr><th>Nom</th><th>Statut</th><th>Lien public</th><th>Vues</th><th>Créé</th><th>Modifié</th></tr></thead>
      <tbody>${rows || '<tr><td colspan="6" class="muted">Aucun site pour le moment.</td></tr>'}</tbody>
    </table>`
  }));
});

function slugify(str) {
  return String(str)
    .toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '')
    .slice(0, 60) || 'site';
}

function uniqueSlug(base) {
  let slug = base;
  let i = 1;
  while (db.prepare('SELECT id FROM sites WHERE slug = ?').get(slug)) {
    slug = `${base}-${i++}`;
  }
  return slug;
}

on('POST', '/sites/create', async (req, res) => {
  const session = requireAuth(req, res);
  if (!session) return;
  const fields = await parseFormBody(req);
  if (!requireCsrf(session, fields, res)) return;
  const name = (fields.name || '').trim();
  if (!name) return redirect(res, '/dashboard');
  const templateKey = TEMPLATES[fields.template] ? fields.template : 'blank';
  const slug = uniqueSlug(slugify(name));
  const info = db.prepare('INSERT INTO sites (owner_id, name, slug, status) VALUES (?, ?, ?, ?)').run(session.user.id, name, slug, 'private');
  const siteId = info.lastInsertRowid;
  const startBlocks = blocks.serializeBlocks(TEMPLATES[templateKey].blocks());
  db.prepare('INSERT INTO pages (site_id, title, slug, is_home, blocks) VALUES (?, ?, ?, 1, ?)').run(siteId, 'Accueil', 'accueil', startBlocks);
  redirect(res, `/sites/${siteId}`);
});

function loadOwnedSite(session, siteId) {
  return db.prepare('SELECT * FROM sites WHERE id = ? AND owner_id = ?').get(siteId, session.user.id);
}

// ===================== SITE DETAIL =====================
on('GET', '/sites/:id', (req, res, params) => {
  const session = requireAuth(req, res);
  if (!session) return;
  const site = loadOwnedSite(session, params.id);
  if (!site) return html(res, 404, page({ title: 'Introuvable', user: session.user, body: '<p>Site introuvable.</p>' }));
  const pages = db.prepare('SELECT * FROM pages WHERE site_id = ? ORDER BY is_home DESC, id ASC').all(site.id);
  const pageRows = pages.map(p => `
    <tr>
      <td>${escapeHtml(p.title)}${p.is_home ? ' <span class="badge">Accueil</span>' : ''}</td>
      <td>${escapeHtml(p.slug)}</td>
      <td>${p.views}</td>
      <td>
        <a href="/sites/${site.id}/pages/${p.id}/edit">Modifier</a>
        · <a href="/sites/${site.id}/pages/${p.id}/preview" target="_blank">Aperçu</a>
        ${!p.is_home ? `· <form method="POST" action="/sites/${site.id}/pages/${p.id}/delete" style="display:inline" onsubmit="return confirm('Supprimer cette page ?')"><input type="hidden" name="_csrf" value="${escapeHtml(session.csrfToken)}"><button class="link-btn danger" type="submit">Supprimer</button></form>` : ''}
      </td>
    </tr>`).join('');

  html(res, 200, page({
    title: site.name,
    user: session.user,
    body: `
    <h1>${escapeHtml(site.name)}</h1>
    <p>
      <span class="badge ${site.status}">${site.status === 'public' ? 'Public' : 'Privé'}</span>
      ${site.status === 'public' ? ` · <a href="/s/${escapeHtml(site.slug)}" target="_blank">Voir le site en ligne</a>` : ''}
      · ${site.views} vues au total
    </p>

    <div class="card">
      <h2>Paramètres du site</h2>
      <form method="POST" action="/sites/${site.id}/rename" class="inline-form">
        <input type="hidden" name="_csrf" value="${escapeHtml(session.csrfToken)}">
        <input type="text" name="name" value="${escapeHtml(site.name)}">
        <button type="submit">Renommer</button>
      </form>
      <form method="POST" action="/sites/${site.id}/toggle-status" class="inline-form">
        <input type="hidden" name="_csrf" value="${escapeHtml(session.csrfToken)}">
        <button type="submit">${site.status === 'public' ? 'Rendre privé' : 'Publier (rendre public)'}</button>
      </form>
      <form method="POST" action="/sites/${site.id}/delete" class="inline-form" onsubmit="return confirm('Supprimer définitivement ce site et toutes ses pages ?')">
        <input type="hidden" name="_csrf" value="${escapeHtml(session.csrfToken)}">
        <button type="submit" class="danger">Supprimer le site</button>
      </form>
    </div>

    <div class="card">
      <h2>Pages</h2>
      <table class="data-table">
        <thead><tr><th>Titre</th><th>Slug</th><th>Vues</th><th>Actions</th></tr></thead>
        <tbody>${pageRows}</tbody>
      </table>
      <form method="POST" action="/sites/${site.id}/pages/create" class="inline-form">
        <input type="hidden" name="_csrf" value="${escapeHtml(session.csrfToken)}">
        <input type="text" name="title" placeholder="Titre de la nouvelle page" required>
        <button type="submit">+ Ajouter une page</button>
      </form>
    </div>`
  }));
});

on('POST', '/sites/:id/rename', async (req, res, params) => {
  const session = requireAuth(req, res);
  if (!session) return;
  const site = loadOwnedSite(session, params.id);
  if (!site) return html(res, 404, 'Site introuvable');
  const fields = await parseFormBody(req);
  if (!requireCsrf(session, fields, res)) return;
  const name = (fields.name || '').trim();
  if (name) db.prepare('UPDATE sites SET name = ?, updated_at = datetime(\'now\') WHERE id = ?').run(name, site.id);
  redirect(res, `/sites/${site.id}`);
});

on('POST', '/sites/:id/toggle-status', async (req, res, params) => {
  const session = requireAuth(req, res);
  if (!session) return;
  const site = loadOwnedSite(session, params.id);
  if (!site) return html(res, 404, 'Site introuvable');
  const fields = await parseFormBody(req);
  if (!requireCsrf(session, fields, res)) return;
  const newStatus = site.status === 'public' ? 'private' : 'public';
  db.prepare('UPDATE sites SET status = ?, updated_at = datetime(\'now\') WHERE id = ?').run(newStatus, site.id);
  redirect(res, `/sites/${site.id}`);
});

on('POST', '/sites/:id/delete', async (req, res, params) => {
  const session = requireAuth(req, res);
  if (!session) return;
  const site = loadOwnedSite(session, params.id);
  if (!site) return html(res, 404, 'Site introuvable');
  const fields = await parseFormBody(req);
  if (!requireCsrf(session, fields, res)) return;
  db.prepare('DELETE FROM sites WHERE id = ?').run(site.id);
  redirect(res, '/dashboard');
});

on('POST', '/sites/:id/pages/create', async (req, res, params) => {
  const session = requireAuth(req, res);
  if (!session) return;
  const site = loadOwnedSite(session, params.id);
  if (!site) return html(res, 404, 'Site introuvable');
  const fields = await parseFormBody(req);
  if (!requireCsrf(session, fields, res)) return;
  const title = (fields.title || '').trim();
  if (!title) return redirect(res, `/sites/${site.id}`);
  const slug = title.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') || 'page';
  let finalSlug = slug, i = 1;
  while (db.prepare('SELECT id FROM pages WHERE site_id = ? AND slug = ?').get(site.id, finalSlug)) finalSlug = `${slug}-${i++}`;
  const info = db.prepare('INSERT INTO pages (site_id, title, slug, blocks) VALUES (?, ?, ?, ?)').run(site.id, title, finalSlug, '[]');
  redirect(res, `/sites/${site.id}/pages/${info.lastInsertRowid}/edit`);
});

function loadOwnedPage(session, siteId, pageId) {
  const site = loadOwnedSite(session, siteId);
  if (!site) return null;
  const pg = db.prepare('SELECT * FROM pages WHERE id = ? AND site_id = ?').get(pageId, site.id);
  if (!pg) return null;
  return { site, page: pg };
}

on('GET', '/sites/:id/pages/:pageId/edit', (req, res, params) => {
  const session = requireAuth(req, res);
  if (!session) return;
  const found = loadOwnedPage(session, params.id, params.pageId);
  if (!found) return html(res, 404, page({ title: 'Introuvable', user: session.user, body: '<p>Page introuvable.</p>' }));
  const blockList = blocks.parseBlocks(found.page.blocks);
  html(res, 200, page({
    title: `Éditer : ${found.page.title}`,
    user: session.user,
    body: `
    <p><a href="/sites/${found.site.id}">&larr; ${escapeHtml(found.site.name)}</a></p>
    <h1>Éditer : ${escapeHtml(found.page.title)}</h1>
    ${blocks.renderBlockEditor(blockList, session.csrfToken)}
    `
  }));
});

on('POST', '/sites/:id/pages/:pageId/edit', async (req, res, params) => {
  const session = requireAuth(req, res);
  if (!session) return;
  const found = loadOwnedPage(session, params.id, params.pageId);
  if (!found) return html(res, 404, 'Page introuvable');
  const fields = await parseFormBody(req);
  if (!requireCsrf(session, fields, res)) return;
  const current = blocks.parseBlocks(found.page.blocks);
  const updated = blocks.applyEditorAction(fields, current);
  db.prepare('UPDATE pages SET blocks = ?, updated_at = datetime(\'now\') WHERE id = ?').run(blocks.serializeBlocks(updated), found.page.id);
  db.prepare('UPDATE sites SET updated_at = datetime(\'now\') WHERE id = ?').run(found.site.id);
  redirect(res, `/sites/${found.site.id}/pages/${found.page.id}/edit`);
});

on('POST', '/sites/:id/pages/:pageId/delete', async (req, res, params) => {
  const session = requireAuth(req, res);
  if (!session) return;
  const found = loadOwnedPage(session, params.id, params.pageId);
  if (!found) return html(res, 404, 'Page introuvable');
  if (found.page.is_home) return redirect(res, `/sites/${found.site.id}`);
  const fields = await parseFormBody(req);
  if (!requireCsrf(session, fields, res)) return;
  db.prepare('DELETE FROM pages WHERE id = ?').run(found.page.id);
  redirect(res, `/sites/${found.site.id}`);
});

on('GET', '/sites/:id/pages/:pageId/preview', (req, res, params) => {
  const session = requireAuth(req, res);
  if (!session) return;
  const found = loadOwnedPage(session, params.id, params.pageId);
  if (!found) return html(res, 404, 'Page introuvable');
  const blockList = blocks.parseBlocks(found.page.blocks);
  html(res, 200, publicPageHtml(found.site, found.page, blockList, true));
});

// ===================== PUBLIC SITE RENDERING =====================
function publicPageHtml(site, pg, blockList, isPreview) {
  const body = blocks.renderBlocksPublic(blockList, { siteSlug: site.slug, pageId: pg.id });
  return `<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${escapeHtml(pg.title)} · ${escapeHtml(site.name)}</title>
<link rel="stylesheet" href="/static/public.css">
</head>
<body>
${isPreview ? '<div class="preview-banner">Aperçu — cette page n\'est visible que par vous</div>' : ''}
<main class="public-site">${body}</main>
</body>
</html>`;
}

on('GET', '/s/:slug', (req, res, params) => {
  const site = db.prepare('SELECT * FROM sites WHERE slug = ? AND status = ?').get(params.slug, 'public');
  if (!site) return html(res, 404, '<h1>404</h1><p>Site introuvable ou privé.</p>');
  const home = db.prepare('SELECT * FROM pages WHERE site_id = ? AND is_home = 1').get(site.id);
  if (!home) return html(res, 404, '<h1>404</h1><p>Ce site n\'a pas encore de page d\'accueil.</p>');
  db.prepare('UPDATE sites SET views = views + 1 WHERE id = ?').run(site.id);
  db.prepare('UPDATE pages SET views = views + 1 WHERE id = ?').run(home.id);
  html(res, 200, publicPageHtml(site, home, blocks.parseBlocks(home.blocks), false));
});

on('GET', '/s/:slug/:pageSlug', (req, res, params) => {
  const site = db.prepare('SELECT * FROM sites WHERE slug = ? AND status = ?').get(params.slug, 'public');
  if (!site) return html(res, 404, '<h1>404</h1><p>Site introuvable ou privé.</p>');
  const pg = db.prepare('SELECT * FROM pages WHERE site_id = ? AND slug = ?').get(site.id, params.pageSlug);
  if (!pg) return html(res, 404, '<h1>404</h1><p>Page introuvable.</p>');
  db.prepare('UPDATE sites SET views = views + 1 WHERE id = ?').run(site.id);
  db.prepare('UPDATE pages SET views = views + 1 WHERE id = ?').run(pg.id);
  html(res, 200, publicPageHtml(site, pg, blocks.parseBlocks(pg.blocks), false));
});

on('POST', '/s/:slug/submit/:pageId', async (req, res, params) => {
  const site = db.prepare('SELECT * FROM sites WHERE slug = ? AND status = ?').get(params.slug, 'public');
  if (!site) return html(res, 404, '<h1>404</h1>');
  const pg = db.prepare('SELECT * FROM pages WHERE id = ? AND site_id = ?').get(params.pageId, site.id);
  if (!pg) return html(res, 404, '<h1>404</h1>');
  const fields = await parseFormBody(req);
  db.prepare('INSERT INTO submissions (site_id, page_id, data) VALUES (?, ?, ?)').run(site.id, pg.id, JSON.stringify(fields));
  html(res, 200, `<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8"><link rel="stylesheet" href="/static/public.css"></head><body><main class="public-site"><div class="block block-text"><h2>Merci !</h2><p>Votre message a bien été envoyé.</p><a href="/s/${escapeHtml(site.slug)}">Retour au site</a></div></main></body></html>`);
});

// ===================== STATIC FILES =====================
const STATIC_FILES = {
  '/static/style.css': path.join(__dirname, 'public', 'style.css'),
  '/static/public.css': path.join(__dirname, 'public', 'public.css'),
};

// ===================== SERVER =====================
const server = http.createServer(async (req, res) => {
  try {
    const u = new URL(req.url, `http://${req.headers.host}`);
    const pathname = decodeURIComponent(u.pathname);

    if (STATIC_FILES[pathname]) {
      const filePath = STATIC_FILES[pathname];
      fs.readFile(filePath, (err, data) => {
        if (err) return send(res, 404, 'Not found');
        send(res, 200, data, { 'Content-Type': 'text/css; charset=utf-8', 'Cache-Control': 'public, max-age=3600' });
      });
      return;
    }

    for (const r of routes) {
      if (r.method !== req.method) continue;
      const m = pathname.match(r.regex);
      if (!m) continue;
      const params = {};
      r.paramNames.forEach((name, i) => (params[name] = m[i + 1]));
      await r.handler(req, res, params);
      return;
    }

    // First-run redirect: if no admin exists yet, send everything to /setup
    if (!auth.hasAdminUser() && pathname !== '/setup') {
      return redirect(res, '/setup');
    }

    html(res, 404, page({ title: '404', body: '<h1>404</h1><p>Page introuvable.</p>' }));
  } catch (err) {
    console.error(err);
    send(res, 500, 'Erreur serveur interne', { 'Content-Type': 'text/plain; charset=utf-8' });
  }
});

server.listen(PORT, () => {
  console.log(`SiteBuilder démarré : http://localhost:${PORT}`);
  if (!auth.hasAdminUser()) console.log('Aucun administrateur trouvé -> visitez /setup pour créer votre compte.');
});
