'use strict';
const { escapeHtml } = require('./util');

function layout({ title, body, user, flash }) {
  return `<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${escapeHtml(title)} · SiteBuilder</title>
<link rel="stylesheet" href="/static/style.css">
</head>
<body>
${user ? `
<header class="topbar">
  <a class="brand" href="/dashboard">SiteBuilder</a>
  <nav>
    <a href="/dashboard">Tableau de bord</a>
    <a href="/account">Mon compte</a>
    <form method="POST" action="/logout" style="display:inline">
      <button class="link-btn" type="submit">Déconnexion</button>
    </form>
  </nav>
</header>` : ''}
<main class="container">
${flash ? `<div class="flash ${flash.type}">${escapeHtml(flash.message)}</div>` : ''}
${body}
</main>
</body>
</html>`;
}

module.exports = { layout };
