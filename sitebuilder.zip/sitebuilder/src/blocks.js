'use strict';
const { escapeHtml, safeUrl } = require('./util');

const BLOCK_TYPES = {
  text: { label: 'Texte', fields: [{ key: 'text', label: 'Contenu', type: 'textarea' }] },
  image: {
    label: 'Image',
    fields: [
      { key: 'url', label: 'URL de l\'image', type: 'text' },
      { key: 'alt', label: 'Texte alternatif', type: 'text' },
    ],
  },
  video: {
    label: 'Vidéo (URL embed, ex. YouTube)',
    fields: [{ key: 'url', label: 'URL embed de la vidéo', type: 'text' }],
  },
  button: {
    label: 'Bouton',
    fields: [
      { key: 'label', label: 'Texte du bouton', type: 'text' },
      { key: 'url', label: 'Lien (URL)', type: 'text' },
    ],
  },
  form: {
    label: 'Formulaire de contact',
    fields: [
      { key: 'title', label: 'Titre du formulaire', type: 'text' },
      { key: 'fields', label: 'Champs (séparés par des virgules, ex: nom,email,message)', type: 'text' },
    ],
  },
};

function emptyBlock(type) {
  const block = { type };
  (BLOCK_TYPES[type]?.fields || []).forEach(f => (block[f.key] = ''));
  return block;
}

function parseBlocks(json) {
  try {
    const arr = JSON.parse(json || '[]');
    return Array.isArray(arr) ? arr : [];
  } catch {
    return [];
  }
}

function serializeBlocks(blocks) {
  return JSON.stringify(blocks);
}

// --- Admin editor rendering: one fieldset per block, server-driven (no client JS required) ---
function renderBlockEditor(blocks, csrfToken) {
  const items = blocks
    .map((b, i) => {
      const def = BLOCK_TYPES[b.type];
      if (!def) return '';
      const fieldsHtml = def.fields
        .map(f => {
          const val = escapeHtml(b[f.key] || '');
          const name = `block_${i}_${f.key}`;
          if (f.type === 'textarea') {
            return `<label>${escapeHtml(f.label)}<textarea name="${name}" rows="4">${val}</textarea></label>`;
          }
          return `<label>${escapeHtml(f.label)}<input type="text" name="${name}" value="${val}"></label>`;
        })
        .join('');
      return `
      <fieldset class="block-item">
        <legend>${escapeHtml(def.label)} #${i + 1}</legend>
        <input type="hidden" name="block_${i}_type" value="${escapeHtml(b.type)}">
        ${fieldsHtml}
        <div class="block-actions">
          ${i > 0 ? `<button type="submit" name="action" value="moveup_${i}">↑ Monter</button>` : ''}
          ${i < blocks.length - 1 ? `<button type="submit" name="action" value="movedown_${i}">↓ Descendre</button>` : ''}
          <button type="submit" name="action" value="remove_${i}" class="danger">Supprimer</button>
        </div>
      </fieldset>`;
    })
    .join('');

  const addOptions = Object.entries(BLOCK_TYPES)
    .map(([type, def]) => `<option value="${type}">${escapeHtml(def.label)}</option>`)
    .join('');

  return `
  <form method="POST" class="block-editor">
    <input type="hidden" name="_csrf" value="${escapeHtml(csrfToken)}">
    <input type="hidden" name="block_count" value="${blocks.length}">
    ${items || '<p class="muted">Aucun bloc pour le moment. Ajoutez-en un ci-dessous.</p>'}
    <div class="add-block">
      <select name="new_block_type">${addOptions}</select>
      <button type="submit" name="action" value="add">+ Ajouter un bloc</button>
    </div>
    <div class="save-row">
      <button type="submit" name="action" value="save" class="primary">Enregistrer la page</button>
    </div>
  </form>`;
}

// Rebuild the blocks array from posted form fields, applying add/remove/move/save actions.
function applyEditorAction(fields, blocks) {
  const count = parseInt(fields.block_count || '0', 10) || 0;
  const rebuilt = [];
  for (let i = 0; i < count; i++) {
    const type = fields[`block_${i}_type`];
    if (!BLOCK_TYPES[type]) continue;
    const block = { type };
    BLOCK_TYPES[type].fields.forEach(f => {
      block[f.key] = fields[`block_${i}_${f.key}`] || '';
    });
    rebuilt.push(block);
  }

  const action = fields.action || '';
  if (action === 'add') {
    const type = fields.new_block_type;
    if (BLOCK_TYPES[type]) rebuilt.push(emptyBlock(type));
  } else if (action.startsWith('remove_')) {
    const idx = parseInt(action.split('_')[1], 10);
    rebuilt.splice(idx, 1);
  } else if (action.startsWith('moveup_')) {
    const idx = parseInt(action.split('_')[1], 10);
    if (idx > 0) [rebuilt[idx - 1], rebuilt[idx]] = [rebuilt[idx], rebuilt[idx - 1]];
  } else if (action.startsWith('movedown_')) {
    const idx = parseInt(action.split('_')[1], 10);
    if (idx < rebuilt.length - 1) [rebuilt[idx + 1], rebuilt[idx]] = [rebuilt[idx], rebuilt[idx + 1]];
  }
  // action === 'save' just persists rebuilt as-is

  return rebuilt;
}

// --- Public-facing rendering: every user-supplied value is escaped or URL-sanitized ---
function renderBlocksPublic(blocks, { siteSlug, pageId }) {
  return blocks
    .map(b => {
      switch (b.type) {
        case 'text':
          return `<div class="block block-text">${escapeHtml(b.text || '').replace(/\n/g, '<br>')}</div>`;
        case 'image':
          return `<div class="block block-image"><img src="${safeUrl(b.url)}" alt="${escapeHtml(b.alt || '')}" loading="lazy"></div>`;
        case 'video':
          return `<div class="block block-video"><iframe src="${safeUrl(b.url)}" frameborder="0" allowfullscreen></iframe></div>`;
        case 'button':
          return `<div class="block block-button"><a class="btn" href="${safeUrl(b.url)}">${escapeHtml(b.label || 'En savoir plus')}</a></div>`;
        case 'form': {
          const fieldNames = (b.fields || 'nom,email,message').split(',').map(s => s.trim()).filter(Boolean);
          const inputs = fieldNames
            .map(name => `<label>${escapeHtml(name)}<input type="text" name="${escapeHtml(name)}" required></label>`)
            .join('');
          return `<div class="block block-form">
            <form method="POST" action="/s/${escapeHtml(siteSlug)}/submit/${pageId}">
              <h3>${escapeHtml(b.title || 'Contact')}</h3>
              ${inputs}
              <button type="submit">Envoyer</button>
            </form>
          </div>`;
        }
        default:
          return '';
      }
    })
    .join('\n');
}

module.exports = {
  BLOCK_TYPES,
  emptyBlock,
  parseBlocks,
  serializeBlocks,
  renderBlockEditor,
  applyEditorAction,
  renderBlocksPublic,
};
